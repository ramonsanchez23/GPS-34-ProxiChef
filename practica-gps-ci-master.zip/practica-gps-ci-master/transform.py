""" fitxer de funcions auxiliars"""


def to_upper_case(string):
    """string to upper case"""
    return string.upper()


def to_lower_case(string):
    """ string to lower case"""
    return string.lower()


def to_capitalize(string):
    """ string capitalized"""
    return string.capitalize()
